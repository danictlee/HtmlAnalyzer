public class MalformedHtmlException extends Exception {
    public MalformedHtmlException() {
        super("malformed HTML");
    }
}